export const siteConfig = {
  name: "TaskMaster",
  title: "Your Ultimate Todo List Manager", 
  description: "Organize, prioritize, and complete your tasks with ease. Built with Next.js and modern technologies."
};
